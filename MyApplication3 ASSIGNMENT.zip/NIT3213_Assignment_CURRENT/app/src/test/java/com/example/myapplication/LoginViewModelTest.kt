package com.example.myapplication

import com.example.myapplication.data.Repository
import com.example.myapplication.ui.login.LoginViewModel
import com.example.myapplication.util.UiState
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

/**
 * Unit tests verifying input validation and state transitions in [LoginViewModel].
 * Uses MockK to mock repository responses and Coroutines test dispatchers.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class LoginViewModelTest {

    // Test dispatcher for managing coroutine execution order in tests
    private val dispatcher = StandardTestDispatcher()
    
    // Mocked repository for isolating ViewModel tests from network layer
    private val repository = mockk<Repository>()

    @Before
    fun setup() {
        // Set main dispatcher to test dispatcher before running tests
        Dispatchers.setMain(dispatcher)
    }

    @After
    fun tearDown() {
        // Reset main dispatcher after tests complete
        Dispatchers.resetMain()
    }

    @Test
    fun `blank student ID returns validation error`() = runTest {
        // Arrange: Initialize ViewModel
        val vm = LoginViewModel(repository)

        // Act: Attempt login with blank student ID and valid name
        vm.login("", "Tony")

        // Assert: Verify validation error state for missing Student ID
        assertEquals(UiState.Error("Please enter your Student ID."), vm.state.value)
    }

    @Test
    fun `blank student name returns validation error`() = runTest {
        // Arrange: Initialize ViewModel
        val vm = LoginViewModel(repository)

        // Act: Attempt login with valid student ID and blank name
        vm.login("12345678", "")

        // Assert: Verify validation error state for missing Student Name
        assertEquals(UiState.Error("Please enter your Student Name."), vm.state.value)
    }

    @Test
    fun `successful login returns keypass`() = runTest {
        // Arrange: Mock repository login to return a keypass token
        coEvery { repository.login("12345678", "Tony") } returns "topicName"
        val vm = LoginViewModel(repository)

        // Act: Perform login with valid credentials and process pending coroutines
        vm.login("12345678", "Tony")
        runCurrent()

        // Assert: Verify that the UI state successfully returns the keypass
        assertEquals(UiState.Success("topicName"), vm.state.value)
    }
}
