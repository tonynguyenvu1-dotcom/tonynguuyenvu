package com.example.myapplication

import com.example.myapplication.data.Repository
import com.example.myapplication.data.remote.ApiService
import com.example.myapplication.model.LoginResponse
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.assertEquals
import org.junit.Test
import retrofit2.HttpException
import retrofit2.Response
import java.io.IOException

/**
 * Unit tests verifying endpoint invocation and error translation logic in [Repository].
 * Tests correct mapping of parameters to backend requests and robust friendly error conversions.
 */
class RepositoryTest {

    // Mocked ApiService to simulate backend network responses
    private val api = mockk<ApiService>()
    
    // Repository instance under test
    private val repository = Repository(api)

    @Test
    fun `login calls the Footscray auth endpoint with correct payload parameter mapping`() = runTest {
        // Arrange: Mock ApiService login response expecting mapped credentials
        coEvery { api.login(match { it.username == "12345678" && it.password == "Tony" }) } returns LoginResponse("topicName")

        // Act: Call repository login method
        val result = repository.login("12345678", "Tony")

        // Assert: Verify returned keypass matches expected value
        assertEquals("topicName", result)
    }

    @Test
    fun `friendlyError handles network failures`() {
        // Arrange & Act: Convert an IOException using friendlyError
        val errorMsg = repository.friendlyError(IOException())

        // Assert: Verify user-friendly connectivity error message is returned
        assertEquals(
            "Unable to connect to the server. Check your internet connection and try again.",
            errorMsg
        )
    }

    @Test
    fun `friendlyError handles unauthorized responses`() {
        // Arrange: Create a 401 Unauthorized HTTP exception
        val exception = HttpException(Response.error<Any>(401, "".toResponseBody(null)))

        // Act: Convert HTTP exception using friendlyError
        val errorMsg = repository.friendlyError(exception)

        // Assert: Verify friendly authentication error message is returned
        assertEquals(
            "Your username or password is incorrect.",
            errorMsg
        )
    }
}
