package com.example.myapplication

import com.example.myapplication.data.Repository
import com.example.myapplication.model.DashboardResponse
import com.example.myapplication.ui.dashboard.DashboardViewModel
import com.example.myapplication.util.UiState
import io.mockk.coEvery
import io.mockk.mockk
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test

/**
 * Unit tests verifying keypass validation and dashboard data loading in [DashboardViewModel].
 * Utilizes MockK for repository mocking and Coroutines test dispatcher for asynchronous operations.
 */
@OptIn(ExperimentalCoroutinesApi::class)
class DashboardViewModelTest {

    // Test dispatcher for controlling coroutines execution in tests
    private val dispatcher = StandardTestDispatcher()
    
    // Mocked repository to isolate ViewModel behavior from network dependencies
    private val repository = mockk<Repository>()

    @Before
    fun setup() {
        // Set the Main dispatcher to test dispatcher before each test
        Dispatchers.setMain(dispatcher)
    }

    @After
    fun tearDown() {
        // Reset the Main dispatcher after each test
        Dispatchers.resetMain()
    }

    @Test
    fun `blank keypass returns validation error`() = runTest {
        // Arrange: Initialize ViewModel with mocked repository
        val vm = DashboardViewModel(repository)

        // Act: Trigger dashboard load with a blank keypass
        vm.load("")

        // Assert: Verify that an error state with appropriate message is emitted
        assertEquals(
            UiState.Error("A valid keypass was not received. Please log in again."),
            vm.state.value
        )
    }

    @Test
    fun `successful dashboard request returns response`() = runTest {
        // Arrange: Prepare mock dashboard response and mock repository response
        val response = DashboardResponse(listOf(mapOf("name" to "Test", "description" to "Details")), 1)
        coEvery { repository.getDashboard("topicName") } returns response
        val vm = DashboardViewModel(repository)

        // Act: Load dashboard with valid keypass and run pending coroutines
        vm.load("topicName")
        runCurrent()

        // Assert: Verify that the state successfully holds the returned dashboard response
        assertEquals(UiState.Success(response), vm.state.value)
    }
}
