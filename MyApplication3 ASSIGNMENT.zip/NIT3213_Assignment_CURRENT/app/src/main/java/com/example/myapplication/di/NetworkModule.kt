package com.example.myapplication.di

import com.example.myapplication.BuildConfig
import com.example.myapplication.data.remote.ApiService
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit
import javax.inject.Singleton

/**
 * Hilt module that provides network-related singletons such as OkHttpClient,
 * Moshi, Retrofit, and ApiService instances.
 */
@Module
@InstallIn(SingletonComponent::class)
object NetworkModule {
    /** Base URL for the new NIT3213 REST API. */
    private const val BASE_URL = "https://nit3213apinew.onrender.com/"

    /**
     * Provides an [OkHttpClient] instance configured with logging and extended timeouts.
     * Extended timeouts account for Render free tier web service cold start delays.
     */
    @Provides
    @Singleton
    fun provideOkHttp(): OkHttpClient {
        // Configure HTTP logging interceptor for debug builds
        val logging = HttpLoggingInterceptor().apply {
            level = if (BuildConfig.DEBUG) {
                HttpLoggingInterceptor.Level.BODY
            } else {
                HttpLoggingInterceptor.Level.NONE
            }
        }

        return OkHttpClient.Builder()
            .addInterceptor(logging)
            // Render's free instance tier sleeps when idle; extended timeouts handle cold starts (up to 60-90s)
            .connectTimeout(90, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(90, TimeUnit.SECONDS)
            .callTimeout(120, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }

    /**
     * Provides a [Moshi] JSON parser instance with Kotlin reflection adapter support.
     */
    @Provides
    @Singleton
    fun provideMoshi(): Moshi =
        Moshi.Builder()
            .add(KotlinJsonAdapterFactory())
            .build()

    /**
     * Provides a singleton [Retrofit] HTTP client configured with Moshi and OkHttpClient.
     */
    @Provides
    @Singleton
    fun provideRetrofit(client: OkHttpClient, moshi: Moshi): Retrofit =
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()

    /**
     * Provides the [ApiService] instance created by Retrofit.
     */
    @Provides
    @Singleton
    fun provideApi(retrofit: Retrofit): ApiService = retrofit.create(ApiService::class.java)
}
