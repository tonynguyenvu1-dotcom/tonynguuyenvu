package com.example.myapplication.ui.dashboard

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.databinding.ItemEntityBinding

/**
 * RecyclerView ListAdapter for displaying artwork items on the Dashboard screen.
 *
 * The API may call the artwork title field "artworkTitle", but that technical
 * field name is never shown to the user. Only the actual artwork title is displayed.
 */
class EntityAdapter(private val onClick: (Map<String, Any?>) -> Unit)
    : ListAdapter<Map<String, Any?>, EntityAdapter.VH>(DIFF) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemEntityBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(getItem(position))
    }

    /** ViewHolder binding the artwork title and artist to the dashboard card. */
    inner class VH(private val b: ItemEntityBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(entity: Map<String, Any?>) {
            // Find the actual artwork title from the API data.
            // We display its VALUE only, e.g. "The Scream", not "artworkTitle: The Scream".
            val titleEntry = entity.entries.firstOrNull {
                val key = it.key.lowercase()
                key == "artworktitle" || key == "title"
            }

            // Find the artist separately so the card has a clean two-line layout.
            val artistEntry = entity.entries.firstOrNull {
                it.key.lowercase() == "artist"
            }

            b.tvLine1.text = titleEntry?.value?.toString()?.takeIf { it.isNotBlank() } ?: "Untitled"
            b.tvLine2.text = artistEntry?.value?.toString()?.takeIf { it.isNotBlank() }
                ?.let { "Artist: $it" }
                ?: ""

            b.root.setOnClickListener { onClick(entity) }
        }
    }

    companion object {
        /** DiffUtil callback for efficient RecyclerView updates. */
        val DIFF = object : DiffUtil.ItemCallback<Map<String, Any?>>() {
            override fun areItemsTheSame(o: Map<String, Any?>, n: Map<String, Any?>) = o == n
            override fun areContentsTheSame(o: Map<String, Any?>, n: Map<String, Any?>) = o == n
        }
    }
}
