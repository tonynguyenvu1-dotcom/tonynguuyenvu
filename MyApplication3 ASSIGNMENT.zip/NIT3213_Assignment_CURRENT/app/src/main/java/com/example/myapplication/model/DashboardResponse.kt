package com.example.myapplication.model

import com.squareup.moshi.Json

/**
 * Data class representing the dashboard response from the API.
 *
 * @property entities List of key-value map objects dynamically returned by the API.
 * @property entityTotal Total count of entities returned by the endpoint.
 */
data class DashboardResponse(
    val entities: List<Map<String, Any?>>,
    @Json(name = "entityTotal") val entityTotal: Int
)