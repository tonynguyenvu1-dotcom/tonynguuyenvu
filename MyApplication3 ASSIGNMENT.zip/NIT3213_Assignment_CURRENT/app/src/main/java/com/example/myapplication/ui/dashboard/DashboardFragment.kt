package com.example.myapplication.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.R
import com.example.myapplication.databinding.FragmentDashboardBinding
import com.example.myapplication.model.DashboardResponse
import com.example.myapplication.util.UiState
import com.squareup.moshi.Moshi
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

/**
 * Fragment displaying the list of entities fetched from the dashboard endpoint.
 */
@AndroidEntryPoint
class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!
    private val vm: DashboardViewModel by viewModels()
    private val args: DashboardFragmentArgs by navArgs()
    private lateinit var adapter: EntityAdapter
    private val moshi = Moshi.Builder().build()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize RecyclerView adapter with click listener for item selection
        adapter = EntityAdapter { entity ->
            // Serialize item map to JSON string to pass via SafeArgs to DetailsFragment
            val json = moshi.adapter(Map::class.java).toJson(entity)
            val action = DashboardFragmentDirections.actionDashboardFragmentToDetailsFragment(json)
            findNavController().navigate(action)
        }

        binding.rvEntities.layoutManager = LinearLayoutManager(requireContext())
        binding.rvEntities.adapter = adapter

        // Collect state updates lifecycle-safely
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect { state -> render(state) }
            }
        }

        // Trigger dashboard data load using keypass passed from LoginFragment
        vm.load(args.keypass)
    }

    /**
     * Renders dashboard UI based on the current state.
     */
    private fun render(state: UiState<DashboardResponse>) {
        when (state) {
            UiState.Idle -> showLoading(false)
            UiState.Loading -> {
                showLoading(true)
                binding.llEmptyState.visibility = View.GONE
            }
            is UiState.Success -> {
                showLoading(false)
                val items = state.data.entities
                adapter.submitList(items)

                val isEmpty = items.isEmpty()
                binding.llEmptyState.visibility = if (isEmpty) View.VISIBLE else View.GONE
                binding.tvEmpty.text = if (isEmpty) "No items found." else ""

                val total = state.data.entityTotal
                binding.tvTotalBadge.text = "$total Items"
                binding.tvTotalBadge.visibility = if (total > 0) View.VISIBLE else View.GONE
            }
            is UiState.Error -> {
                showLoading(false)
                binding.tvEmpty.text = state.message
                binding.llEmptyState.visibility = View.VISIBLE
                binding.tvTotalBadge.visibility = View.GONE
            }
        }
    }

    /**
     * Controls visibility of the loading progress indicator and RecyclerView.
     */
    private fun showLoading(loading: Boolean) {
        binding.progress.visibility = if (loading) View.VISIBLE else View.GONE
        binding.rvEntities.visibility = if (loading) View.INVISIBLE else View.VISIBLE
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
