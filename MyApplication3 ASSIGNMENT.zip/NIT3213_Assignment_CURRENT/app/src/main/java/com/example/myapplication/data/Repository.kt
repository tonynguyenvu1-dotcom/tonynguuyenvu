package com.example.myapplication.data

import com.example.myapplication.data.remote.ApiService
import com.example.myapplication.model.DashboardResponse
import com.example.myapplication.model.LoginRequest
import retrofit2.HttpException
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import javax.inject.Inject

/**
 * Repository class acting as the single source of truth for all data operations.
 * 
 * Architectural Role:
 * - Abstracts away the remote API data source ([ApiService]) from the ViewModel and UI layers.
 * - Centralizes error handling, network retry logic, and data request preparation.
 */
class Repository @Inject constructor(private val api: ApiService) {

    /**
     * Authenticates the user against the backend API and returns the secure keypass token.
     * 
     * API Mapping Rule:
     * - The backend expects credentials wrapped in a [LoginRequest].
     * - Per assignment specification: the `username` field accepts the Student ID, 
     *   and the `password` field accepts the Student Name.
     *
     * @param studentId The user's Student ID (passed as username).
     * @param studentName The user's Student Name (passed as password).
     * @return A [String] representing the security keypass token required for dashboard requests.
     */
    suspend fun login(studentId: String, studentName: String): String {
        // Trim whitespace from inputs to prevent accidental formatting issues
        val request = LoginRequest(
            username = studentId.trim(),
            password = studentName.trim()
        )
        // Execute login request wrapped with automatic cold-start retry handling
        return withColdStartRetry { api.login(request).keypass }
    }

    /**
     * Fetches the dashboard entity list and total count using the provided security keypass.
     *
     * @param keypass The security token received upon successful authentication.
     * @return A [DashboardResponse] containing the list of dynamic entity items and entity total.
     */
    suspend fun getDashboard(keypass: String): DashboardResponse =
        withColdStartRetry { api.getDashboard(keypass) }

    /**
     * Helper wrapper that automatically retries a suspending network operation once 
     * if a [SocketTimeoutException] is encountered.
     * 
     * Why this is needed:
     * - The backend API is hosted on Render's free tier, which puts web service instances 
     *   to sleep after periods of inactivity (cold start). The first request can take up 
     *   to 60–90 seconds to spin up the instance, triggering a timeout. Retrying automatically 
     *   ensures a smooth user experience.
     */
    private suspend fun <T> withColdStartRetry(block: suspend () -> T): T =
        try {
            block()
        } catch (e: SocketTimeoutException) {
            // Automatically retry once upon timeout
            block()
        }

    /**
     * Translates low-level system exceptions and HTTP error codes into clear, 
     * user-friendly error messages suitable for display on the UI.
     *
     * @param error The [Throwable] caught during network execution.
     * @return A clear, descriptive error message string.
     */
    fun friendlyError(error: Throwable): String = when (error) {
        is SocketTimeoutException ->
            "The server took too long to respond. Please wait a moment and try again."
        is UnknownHostException ->
            "Cannot reach nit3213apinew.onrender.com. Check your internet connection."
        is IOException ->
            "Unable to connect to the server. Check your internet connection and try again."
        is HttpException -> when (error.code()) {
            400 -> "The login details were not accepted. Please check your details."
            401, 403 -> "Your username or password is incorrect."
            404 -> "The Footscray login endpoint was not found on the API server."
            500, 502, 503, 504 -> "The API server is temporarily unavailable. Please try again later."
            else -> "The API server returned an error (${error.code()})."
        }
        else -> error.message?.takeIf { it.isNotBlank() } ?: "Something went wrong. Please try again."
    }
}
