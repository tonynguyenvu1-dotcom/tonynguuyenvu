package com.example.myapplication.data.remote

import com.example.myapplication.model.DashboardResponse
import com.example.myapplication.model.LoginRequest
import com.example.myapplication.model.LoginResponse
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path

/**
 * Retrofit interface defining network operations for the NIT3213 backend API.
 */
interface ApiService {

    /**
     * Authenticates the user with the specified campus endpoint (Footscray).
     *
     * @param body [LoginRequest] containing username and password.
     * @return [LoginResponse] containing the keypass token on success.
     */
    @POST("footscray/auth")
    suspend fun login(@Body body: LoginRequest): LoginResponse

    /**
     * Retrieves dashboard entity items using the keypass obtained during authentication.
     *
     * @param keypass Security token received from the auth endpoint.
     * @return [DashboardResponse] containing list of entities.
     */
    @GET("dashboard/{keypass}")
    suspend fun getDashboard(@Path("keypass") keypass: String): DashboardResponse
}
