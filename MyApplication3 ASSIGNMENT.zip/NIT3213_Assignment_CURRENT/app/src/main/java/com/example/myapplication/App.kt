package com.example.myapplication

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Application class for the app.
 * The @HiltAndroidApp annotation triggers Hilt's code generation,
 * serving as the application-level dependency container.
 */
@HiltAndroidApp
class App : Application()