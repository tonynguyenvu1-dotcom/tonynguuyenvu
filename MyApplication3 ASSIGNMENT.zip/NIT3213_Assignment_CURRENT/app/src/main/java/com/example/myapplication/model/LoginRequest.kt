package com.example.myapplication.model

/**
 * Data class representing the payload sent in the POST request during authentication.
 *
 * @property username Student ID (as required by the API specification).
 * @property password Student Name (as required by the API specification).
 */
data class LoginRequest(val username: String, val password: String)