package com.example.myapplication.util

/**
 * A generic sealed class representing the different states of the UI layer.
 * This pattern ensures type-safe state management across ViewModels and Views.
 *
 * @param T The type of data held when in [Success] state.
 */
sealed class UiState<out T> {
    /** Initial state before any action is triggered. */
    object Idle : UiState<Nothing>()

    /** State indicating an active asynchronous operation (e.g., network call). */
    object Loading : UiState<Nothing>()

    /** State containing the successfully retrieved data. */
    data class Success<T>(val data: T) : UiState<T>()

    /** State containing an error message to display to the user. */
    data class Error(val message: String) : UiState<Nothing>()
}