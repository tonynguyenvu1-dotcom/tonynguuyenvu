package com.example.myapplication.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.R
import dagger.hilt.android.AndroidEntryPoint

/**
 * Main entry activity holding the Navigation Host Fragment.
 * Annotated with @AndroidEntryPoint so Hilt can inject dependencies into fragments hosted here.
 */
@AndroidEntryPoint
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}