package com.example.myapplication.ui.login

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.data.Repository
import com.example.myapplication.util.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel managing the state and user authentication logic for [LoginFragment].
 * Evaluates field inputs and executes the authentication call via [Repository].
 */
@HiltViewModel
class LoginViewModel @Inject constructor(
    private val repo: Repository
) : ViewModel() {

    // Internal state flow that manages the current UI state of the login flow
    private val _state = MutableStateFlow<UiState<String>>(UiState.Idle)

    /** Read-only UI state exposed to the fragment. */
    val state: StateFlow<UiState<String>> = _state.asStateFlow()

    /**
     * Validates input fields and executes login POST request.
     *
     * @param studentId User's entered Student ID.
     * @param studentName User's entered Student Name.
     */
    fun login(studentId: String, studentName: String) {
        // Step 1: Client-side validation
        when {
            studentId.isBlank() -> {
                _state.value = UiState.Error("Please enter your Student ID.")
                return
            }
            studentName.isBlank() -> {
                _state.value = UiState.Error("Please enter your Student Name.")
                return
            }
        }

        // Step 2: Trigger loading state and start background coroutine for network request
        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                val keypass = repo.login(studentId, studentName)
                _state.value = UiState.Success(keypass)
            } catch (e: Exception) {
                _state.value = UiState.Error(repo.friendlyError(e))
            }
        }
    }
}
