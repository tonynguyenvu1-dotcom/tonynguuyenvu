package com.example.myapplication.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.data.Repository
import com.example.myapplication.model.DashboardResponse
import com.example.myapplication.util.UiState
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * ViewModel managing the dashboard state and fetching entity items via [Repository].
 */
@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val repo: Repository
) : ViewModel() {

    private val _state = MutableStateFlow<UiState<DashboardResponse>>(UiState.Idle)

    /** Read-only state flow exposed to [DashboardFragment]. */
    val state: StateFlow<UiState<DashboardResponse>> = _state.asStateFlow()

    /**
     * Loads the dashboard entities using the provided keypass.
     *
     * @param keypass Security pass obtained from the auth step.
     */
    fun load(keypass: String) {
        if (keypass.isBlank()) {
            _state.value = UiState.Error("A valid keypass was not received. Please log in again.")
            return
        }

        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                _state.value = UiState.Success(repo.getDashboard(keypass))
            } catch (e: Exception) {
                _state.value = UiState.Error(repo.friendlyError(e))
            }
        }
    }
}
