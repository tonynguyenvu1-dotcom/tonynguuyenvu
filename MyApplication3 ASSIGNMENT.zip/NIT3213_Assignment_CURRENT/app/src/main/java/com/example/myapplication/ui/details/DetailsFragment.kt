package com.example.myapplication.ui.details

import android.graphics.Typeface
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.absoluteValue
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.example.myapplication.R
import com.example.myapplication.databinding.FragmentDetailsBinding
import com.google.android.material.card.MaterialCardView
import com.squareup.moshi.Moshi
import dagger.hilt.android.AndroidEntryPoint

/**
 * Fragment responsible for displaying complete details of a selected dashboard item.
 * 
 * Key Responsibilities:
 * - Receives serialized JSON entity map data via Navigation SafeArgs.
 * - Deserializes the JSON map using Moshi.
 * - Dynamically builds and displays a highlighted description card and structured property cards.
 * - Formats technical database field names into clean, human-readable user labels.
 * - Provides a back button to return to the dashboard screen.
 */
@AndroidEntryPoint
class DetailsFragment : Fragment() {
    private var _binding: FragmentDetailsBinding? = null
    private val binding get() = _binding!!
    private val args: DetailsFragmentArgs by navArgs()
    private val moshi = Moshi.Builder().build()

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentDetailsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Wire up back button click listener to navigate back to the dashboard screen
        binding.btnBack.setOnClickListener {
            findNavController().popBackStack()
        }

        try {
            // Step 1: Deserialize JSON string passed from DashboardFragment back into a key-value Map
            val map = moshi.adapter(Map::class.java).fromJson(args.entityJson) as? Map<*, *>
            if (map.isNullOrEmpty()) {
                showMessage("No details are available for this item.")
                return
            }

            // Step 2: Check for a "description" field and render it in a prominent highlighted card if present
            val descriptionEntry = map.entries.firstOrNull { it.key?.toString()?.lowercase() == "description" }
            if (descriptionEntry != null) {
                addDescriptionCard(descriptionEntry.value?.toString() ?: "No description provided.")
            }

            // Step 3: Filter out description and sort remaining properties into a museum-style preferred order
            // Preferred order ensures critical fields like artist, title, medium, and year appear first.
            val preferredOrder = listOf("artist", "artworktitle", "title", "medium", "year")
            val otherEntries = map.entries
                .filter { it.key?.toString()?.lowercase() != "description" }
                .sortedWith(compareBy {
                    val key = it.key?.toString()?.lowercase() ?: ""
                    val index = preferredOrder.indexOf(key)
                    // If not in preferred list, place alphabetically/hash-order afterwards
                    if (index == -1) 100 + key.hashCode().absoluteValue % 1000 else index
                })

            // Step 4: Render all remaining key-value properties inside a structured details card
            if (otherEntries.isNotEmpty()) {
                addPropertiesCard(otherEntries)
            }
        } catch (_: Exception) {
            showMessage("Unable to display the item details.")
        }
    }

    /**
     * Dynamically constructs and adds a highlighted card view specifically for the artwork description.
     * Uses primary theme colors to make the description stand out visually.
     *
     * @param descriptionText The description text content to display.
     */
    private fun addDescriptionCard(descriptionText: String) {
        val card = MaterialCardView(requireContext()).apply {
            radius = dpToPx(14).toFloat()
            elevation = dpToPx(2).toFloat()
            strokeWidth = dpToPx(1)
            strokeColor = ContextCompat.getColor(requireContext(), R.color.primary)
            setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.primary_light))
            
            val layoutParams = ViewGroup.MarginLayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(16)
            }
            this.layoutParams = layoutParams
        }

        val container = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16))
        }

        val titleTv = TextView(requireContext()).apply {
            text = "Description"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(ContextCompat.getColor(requireContext(), R.color.primary_dark))
        }

        val bodyTv = TextView(requireContext()).apply {
            text = descriptionText
            textSize = 15f
            setTextColor(ContextCompat.getColor(requireContext(), R.color.on_surface))
            setLineSpacing(0f, 1.2f)
            setPadding(0, dpToPx(6), 0, 0)
        }

        container.addView(titleTv)
        container.addView(bodyTv)
        card.addView(container)
        binding.containerDetails.addView(card)
    }

    /**
     * Dynamically constructs and adds a card view containing all key-value entity properties.
     * Adds visual divider lines between property rows for clean readability.
     *
     * @param entries List of sorted map entries representing entity attributes.
     */
    private fun addPropertiesCard(entries: List<Map.Entry<*, *>>) {
        val card = MaterialCardView(requireContext()).apply {
            radius = dpToPx(14).toFloat()
            elevation = dpToPx(2).toFloat()
            strokeWidth = dpToPx(1)
            strokeColor = ContextCompat.getColor(requireContext(), R.color.card_stroke)
            setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.surface))
            
            val layoutParams = ViewGroup.MarginLayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dpToPx(16)
            }
            this.layoutParams = layoutParams
        }

        val container = LinearLayout(requireContext()).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16))
        }

        entries.forEachIndexed { index, entry ->
            val row = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                if (index > 0) setPadding(0, dpToPx(12), 0, 0)
            }

            val keyTv = TextView(requireContext()).apply {
                // Format technical database field keys into clean, user-friendly labels (e.g. "artworkTitle" -> "Title")
                text = formatFieldLabel(entry.key?.toString())
                textSize = 12f
                setTypeface(null, Typeface.BOLD)
                setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary))
                letterSpacing = 0.03f
            }

            val valTv = TextView(requireContext()).apply {
                // Format field values (e.g. stripping decimal formatting from whole-number years)
                text = formatFieldValue(entry.key?.toString(), entry.value)
                textSize = 16f
                setTextColor(ContextCompat.getColor(requireContext(), R.color.on_surface))
                setPadding(0, dpToPx(3), 0, 0)
            }

            row.addView(keyTv)
            row.addView(valTv)
            container.addView(row)

            // Add subtle divider line between items (except after the last item)
            if (index < entries.size - 1) {
                val divider = View(requireContext()).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        dpToPx(1)
                    ).apply {
                        topMargin = dpToPx(10)
                    }
                    setBackgroundColor(ContextCompat.getColor(requireContext(), R.color.card_stroke))
                }
                container.addView(divider)
            }
        }

        card.addView(container)
        binding.containerDetails.addView(card)
    }


    /**
     * Converts technical API/database field names into clean, human-readable labels.
     * Examples: "artworkTitle" -> "Title", "artist" -> "Artist", camelCase/snake_case -> Title Case.
     *
     * @param key The raw technical property key.
     * @return Formatted user-facing label string.
     */
    private fun formatFieldLabel(key: String?): String {
        return when (key?.lowercase()) {
            "artworktitle" -> "Title"
            "artist" -> "Artist"
            "medium" -> "Medium"
            "year" -> "Year"
            else -> key
                ?.replace(Regex("([a-z])([A-Z])"), "$1 $2")
                ?.replace("_", " ")
                ?.replace("-", " ")
                ?.trim()
                ?.split(" ")
                ?.joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
                ?: "Field"
        }
    }

    /**
     * Formats property values for display. 
     * Specifically cleans up database-style decimal numbers (e.g., "2020.0" -> "2020") for year fields.
     *
     * @param key The property key name.
     * @param value The raw property value object.
     * @return Formatted value string.
     */
    private fun formatFieldValue(key: String?, value: Any?): String {
        if (value == null) return "—"
        if (key?.lowercase() == "year") {
            val number = value.toString().toDoubleOrNull()
            if (number != null && number % 1.0 == 0.0) return number.toInt().toString()
        }
        return value.toString()
    }

    /** Utility function to convert density-independent pixels (dp) to physical pixels (px). */
    private fun dpToPx(dp: Int): Int =
        (dp * resources.displayMetrics.density).toInt()

    /** Helper method to display error or empty fallback messages in the details layout container. */
    private fun showMessage(message: String) {
        val tv = TextView(requireContext()).apply {
            text = message
            textSize = 16f
            setPadding(8)
        }
        binding.containerDetails.addView(tv)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
