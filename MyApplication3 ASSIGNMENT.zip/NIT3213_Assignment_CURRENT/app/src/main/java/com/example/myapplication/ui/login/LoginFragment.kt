package com.example.myapplication.ui.login

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.fragment.findNavController
import com.example.myapplication.R
import com.example.myapplication.databinding.FragmentLoginBinding
import com.example.myapplication.util.UiState
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch

/**
 * Fragment presenting the Login screen.
 * Handles user input for username and student ID, observing state updates from [LoginViewModel].
 */
@AndroidEntryPoint
class LoginFragment : Fragment() {

    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!
    private val vm: LoginViewModel by viewModels()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Wire login button click event
        binding.btnLogin.setOnClickListener {
            vm.login(
                studentId = binding.etUsername.text.toString(),
                studentName = binding.etPassword.text.toString()
            )
        }

        // Collect UI state changes safely matching the fragment view lifecycle
        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.state.collect(::render)
            }
        }
    }

    /**
     * Renders UI changes based on current [UiState] emitted by [LoginViewModel].
     */
    private fun render(state: UiState<String>) {
        when (state) {
            UiState.Idle -> {
                setLoading(false)
                binding.cvError.visibility = View.GONE
            }
            UiState.Loading -> {
                setLoading(true)
                binding.cvError.visibility = View.GONE
            }
            is UiState.Success -> {
                setLoading(false)
                binding.cvError.visibility = View.GONE
                // Navigate to Dashboard fragment upon successful authentication
                if (findNavController().currentDestination?.id == R.id.loginFragment) {
                    val action = LoginFragmentDirections
                        .actionLoginFragmentToDashboardFragment(state.data)
                    findNavController().navigate(action)
                }
            }
            is UiState.Error -> {
                setLoading(false)
                binding.tvError.text = state.message
                binding.cvError.visibility = View.VISIBLE
            }
        }
    }

    /**
     * Enables or disables input controls and toggles the loading progress bar.
     */
    private fun setLoading(loading: Boolean) {
        binding.progress.visibility = if (loading) View.VISIBLE else View.GONE
        binding.btnLogin.isEnabled = !loading
        binding.etUsername.isEnabled = !loading
        binding.etPassword.isEnabled = !loading
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
