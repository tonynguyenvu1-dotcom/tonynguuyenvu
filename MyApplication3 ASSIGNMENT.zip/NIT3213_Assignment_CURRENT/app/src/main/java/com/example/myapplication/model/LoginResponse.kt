package com.example.myapplication.model

/**
 * Data class representing the JSON response returned after a successful login.
 *
 * @property keypass Security keypass required to fetch the dashboard data.
 */
data class LoginResponse(val keypass: String)