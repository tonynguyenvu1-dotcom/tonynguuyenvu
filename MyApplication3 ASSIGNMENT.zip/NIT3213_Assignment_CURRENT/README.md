# NIT3213 Final Assignment — Android Application

An Android application built for the **NIT3213 Android Application Development** final assignment. This application connects to the NIT3213 REST API using the **Footscray** campus configuration, implementing user authentication, a dashboard list view, and a detailed entity view using modern Android development practices.

---

## Features

- **Login & Authentication**:
  - Authenticates against the assigned campus endpoint (`POST /footscray/auth`).
  - Client-side input validation (ensures Student ID and Student Name are provided).
  - Receives a secure `keypass` token upon successful authentication.

- **Dashboard List**:
  - Fetches and displays entity data from `GET /dashboard/{keypass}` in a `RecyclerView`.
  - Displays summarized field information on clean list items.
  - Handles empty lists and network error states gracefully.

- **Item Details View**:
  - Displays complete key-value details for any selected dashboard item.
  - Fully presents the required `description` field along with all other item attributes.
  - Features an intuitive back button allowing users to easily return to the dashboard.

- **Robust Network Handling**:
  - Handles Render free-tier cold starts with automatic retry mechanisms and extended timeouts.
  - Converts low-level network errors (e.g. timeout, no connection, 401/404 HTTP status) into clear, friendly error messages for the user.

---

## Architecture & Tech Stack

This project strictly follows Google's recommended **MVVM (Model-View-ViewModel)** architecture:

| Component | Technology Used |
| :--- | :--- |
| **Language** | Kotlin (JDK 17) |
| **Architecture** | MVVM + Repository Pattern |
| **Dependency Injection** | Hilt (`@HiltAndroidApp`, `@HiltViewModel`, `@AndroidEntryPoint`) |
| **Async & State** | Kotlin Coroutines + `StateFlow` + `UiState` sealed class |
| **Networking** | Retrofit 2 + OkHttp 4 (with Logging Interceptor) |
| **JSON Serialization** | Moshi (Kotlin reflection adapter) |
| **Navigation** | Jetpack Navigation Component + SafeArgs |
| **UI Layer** | Material Components, XML Views with View Binding |
| **Testing** | JUnit 4, MockK, Coroutines Test (`runTest`, `StandardTestDispatcher`) |

---

## API Specification

- **Base URL**: `https://nit3213apinew.onrender.com`

### 1. Authentication Endpoint
- **Method**: `POST`
- **Route**: `footscray/auth`
- **Request Body**:
  ```json
  {
    "username": "YourStudentID",
    "password": "YourFirstName"
  }
  ```

- **Response Body**:
  ```json
  {
    "keypass": "topicName"
  }
  ```

### 2. Dashboard Endpoint
- **Method**: `GET`
- **Route**: `dashboard/{keypass}`
- **Response Body**:
  ```json
  {
    "entities": [
      {
        "property1": "value1",
        "property2": "value2",
        "description": "Detailed description"
      }
    ],
    "entityTotal": 7
  }
  ```

---

## Project Structure

```text
app/src/main/java/com/example/myapplication
│
├── App.kt                      # @HiltAndroidApp Application entry point
│
├── data/
│   ├── Repository.kt           # Central data source & error handling
│   └── remote/
│       └── ApiService.kt       # Retrofit REST interface definition
│
├── di/
│   └── NetworkModule.kt        # Hilt module (OkHttp, Retrofit, Moshi)
│
├── model/                      # Data payload models
│   ├── LoginRequest.kt
│   ├── LoginResponse.kt
│   └── DashboardResponse.kt
│
├── ui/                         # UI Presentation layer
│   ├── MainActivity.kt         # Single activity hosting NavHostFragment
│   ├── login/                  # LoginFragment & LoginViewModel
│   ├── dashboard/              # DashboardFragment, DashboardViewModel & EntityAdapter
│   └── details/                # DetailsFragment
│
└── util/
    └── UiState.kt              # Sealed class (Idle, Loading, Success, Error)
```

---

## How to Build and Run

### Prerequisites
- **Android Studio** (Ladybug 2024.2+ or later recommended).
- **JDK 17** configured in Android Studio.
- An **Android Emulator** or physical device running Android 7.0 (API 24) or higher with an active internet connection.

### Quick Start Steps

1. **Open Project**: Launch Android Studio and select **Open**, then choose this project folder.
2. **Gradle Sync**: Allow Android Studio to complete the initial Gradle Sync.
3. **Select Target Device**: Choose your preferred emulator or connected device from the device dropdown.
4. **Run App**: Press `Shift + F10` or click the green **Run** button.
5. **Log In**:
   - Enter your **Student ID** in the top box.
   - Enter your **Student Name** in the bottom box.
   - Tap **Sign in**.

---

## Running Unit Tests

The project includes unit test coverage for the ViewModels and Repository.

### Run via Command Line
```bash
./gradlew test
```

### Run in Android Studio
- Right-click the `app/src/test/java/com/example/myapplication` directory and select **Run 'Tests in com.example...'**.

### What is Tested
- `LoginViewModelTest`: Client-side input validation (blank Student ID or Student Name) and successful login state handling.
- `DashboardViewModelTest`: Keypass validation and successful dashboard state emission.
- `RepositoryTest`: Verification of endpoint routes and HTTP error mapping into user-friendly strings.
